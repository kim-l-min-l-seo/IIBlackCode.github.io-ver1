import './styles/main.scss';
import App from './scripts/App';

App.init();
